import React, { useEffect, useMemo, useState } from 'react'

const meterOptions = {
  AC: [
    { id: '250-275', shortLabel: '250–275', maxBTU: 400000 },
    { id: '415-425', shortLabel: '415–425', maxBTU: 630000 },
    { id: '630', shortLabel: '630', maxBTU: 924000 },
  ],
  LC: [
    { id: '250-275', shortLabel: '250–275', maxBTU: 600000 },
    { id: '415-425', shortLabel: '415–425', maxBTU: 900000 },
    { id: '630', shortLabel: '630', maxBTU: 1300000 },
  ],
}

const applianceCatalog = [
  { key: 'gen14', name: '14kW Generator', btu: 230000 },
  { key: 'gen18', name: '18kW Generator', btu: 300000 },
  { key: 'gen22', name: '22kW Generator', btu: 360000 },
  { key: 'gen24', name: '24kW Generator', btu: 390000 },
  { key: 'gen26', name: '26kW Generator', btu: 420000 },
  { key: 'pool_heater', name: 'Pool Heater', btu: 400000 },
  { key: 'central_heat', name: 'Central Heat', btu: 100000 },
  { key: 'water_heater', name: 'Tanked Water Heater', btu: 50000 },
  { key: 'cooktop', name: 'Cooktop', btu: 50000 },
  { key: 'fireplace', name: 'Fireplace', btu: 40000 },
  { key: 'grill', name: 'Grill', btu: 30000 },
  { key: 'oven', name: 'Oven', btu: 20000 },
  { key: 'dryer', name: 'Dryer', btu: 20000 },
]

const pipeOptions = [
  { id: 'none', label: 'Skip pipe check' },
  { id: '1in', label: '1" Reg Pipe' },
  { id: '1.25in', label: '1.25" Reg Pipe' },
]

const pipeCapacityTable = {
  AC: {
    '1"': 420000,
    '1.25"': 420000,
  },
  LC: {
    '1"': 420000,
    '1.25"': 1000000,
  },
}

const storageKey = 'gas-meter-upgrade-calculator-v3'

function makeInitialCounts() {
  return applianceCatalog.reduce((acc, item) => {
    acc[item.key] = 0
    return acc
  }, {})
}

function formatNumber(value) {
  return new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 }).format(Number(value || 0))
}

function classNames(...values) {
  return values.filter(Boolean).join(' ')
}

const styles = {
  page: {
    minHeight: '100vh',
    background: '#f1f5f9',
    padding: '12px',
  },
  shell: {
    maxWidth: '460px',
    margin: '0 auto',
    display: 'grid',
    gap: '16px',
  },
  card: {
    background: '#fff',
    border: '1px solid #e2e8f0',
    borderRadius: '24px',
    padding: '16px',
    boxShadow: '0 1px 3px rgba(15, 23, 42, 0.08)',
  },
  button: {
    borderRadius: '18px',
    border: '1px solid #cbd5e1',
    background: '#fff',
    padding: '12px 14px',
    fontWeight: 700,
    color: '#334155',
    cursor: 'pointer',
    boxShadow: '0 1px 2px rgba(15, 23, 42, 0.06)',
  },
  activeButton: {
    background: '#0f172a',
    color: '#fff',
    borderColor: '#0f172a',
  },
  input: {
    width: '100%',
    borderRadius: '18px',
    border: '1px solid #cbd5e1',
    padding: '12px 14px',
    fontSize: '16px',
    outline: 'none',
  },
}

export default function App() {
  const [meterClass, setMeterClass] = useState('AC')
  const [selectedMeterId, setSelectedMeterId] = useState('415-425')
  const [counts, setCounts] = useState(makeInitialCounts)
  const [customerName, setCustomerName] = useState('')
  const [jobAddress, setJobAddress] = useState('')
  const [selectedPipe, setSelectedPipe] = useState('none')
  const [salesMode, setSalesMode] = useState(false)
  const [savedJobs, setSavedJobs] = useState([])
  const [installPromptEvent, setInstallPromptEvent] = useState(null)
  const [installMessage, setInstallMessage] = useState('')

  useEffect(() => {
    try {
      const raw = localStorage.getItem(storageKey)
      if (!raw) return
      const parsed = JSON.parse(raw)
      if (parsed.meterClass) setMeterClass(parsed.meterClass)
      if (parsed.selectedMeterId) setSelectedMeterId(parsed.selectedMeterId)
      if (parsed.counts) setCounts({ ...makeInitialCounts(), ...parsed.counts })
      if (parsed.customerName) setCustomerName(parsed.customerName)
      if (parsed.jobAddress) setJobAddress(parsed.jobAddress)
      if (parsed.selectedPipe) setSelectedPipe(parsed.selectedPipe)
      if (Array.isArray(parsed.savedJobs)) setSavedJobs(parsed.savedJobs)
    } catch (error) {
      console.error('Unable to load saved data:', error)
    }
  }, [])

  useEffect(() => {
    try {
      localStorage.setItem(
        storageKey,
        JSON.stringify({
          meterClass,
          selectedMeterId,
          counts,
          customerName,
          jobAddress,
          selectedPipe,
          savedJobs,
        }),
      )
    } catch (error) {
      console.error('Unable to save local data:', error)
    }
  }, [meterClass, selectedMeterId, counts, customerName, jobAddress, selectedPipe, savedJobs])

  useEffect(() => {
    const handleBeforeInstallPrompt = (event) => {
      event.preventDefault()
      setInstallPromptEvent(event)
      setInstallMessage('Install is available on this device.')
    }
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt)
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt)
  }, [])

  const activeMeterOptions = meterOptions[meterClass] || meterOptions.AC
  const selectedMeter = activeMeterOptions.find((meter) => meter.id === selectedMeterId) || activeMeterOptions[0]
  const selectedPipeLabel = selectedPipe === '1in' ? '1"' : selectedPipe === '1.25in' ? '1.25"' : null
  const pipeMaxBTU = selectedPipeLabel ? pipeCapacityTable[meterClass]?.[selectedPipeLabel] ?? null : null

  const result = useMemo(() => {
    const lineItems = applianceCatalog
      .map((item) => {
        const qty = Number(counts[item.key] || 0)
        const total = qty * item.btu
        return { ...item, qty, total }
      })
      .filter((item) => item.qty > 0)

    const totalLoad = lineItems.reduce((sum, item) => sum + item.total, 0)
    const remainingMeter = selectedMeter.maxBTU - totalLoad
    const overloadedMeter = totalLoad > selectedMeter.maxBTU
    const percentUsed = selectedMeter.maxBTU ? (totalLoad / selectedMeter.maxBTU) * 100 : 0
    const remainingPipe = typeof pipeMaxBTU === 'number' ? pipeMaxBTU - totalLoad : null
    const overloadedPipe = typeof pipeMaxBTU === 'number' ? totalLoad > pipeMaxBTU : false
    const nextRecommendedMeter = activeMeterOptions.find((meter) => totalLoad <= meter.maxBTU) || null

    return {
      lineItems,
      totalLoad,
      remainingMeter,
      overloadedMeter,
      percentUsed,
      remainingPipe,
      overloadedPipe,
      nextRecommendedMeter,
    }
  }, [counts, selectedMeter, activeMeterOptions, pipeMaxBTU])

  const recommendationText = result.nextRecommendedMeter
    ? result.nextRecommendedMeter.id === selectedMeter.id
      ? `${meterClass} ${selectedMeter.shortLabel} meter works for this load.`
      : `Upgrade to ${meterClass} ${result.nextRecommendedMeter.shortLabel} meter.`
    : 'Load is above the meter sizes currently built into this tool.'

  function setQty(key, value) {
    const cleaned = Math.max(0, Number(value || 0))
    setCounts((prev) => ({ ...prev, [key]: cleaned }))
  }

  function resetAll() {
    setCounts(makeInitialCounts())
    setCustomerName('')
    setJobAddress('')
    setSelectedPipe('none')
  }

  function handleMeterClassChange(nextClass) {
    setMeterClass(nextClass)
    setSelectedMeterId('415-425')
  }

  function saveJob() {
    const newJob = {
      id: String(Date.now()),
      customerName: customerName || 'Unnamed Customer',
      jobAddress,
      meterClass,
      selectedMeterLabel: selectedMeter.shortLabel,
      totalLoad: result.totalLoad,
      recommendation: result.nextRecommendedMeter
        ? `${meterClass} ${result.nextRecommendedMeter.shortLabel}`
        : 'Above available meter sizes',
      timestamp: new Date().toLocaleString(),
    }
    setSavedJobs((prev) => [newJob, ...prev].slice(0, 10))
  }

  async function exportJob() {
    const text = [
      `Customer: ${customerName || ''}`,
      `Address: ${jobAddress || ''}`,
      `Sizing Type: ${meterClass}`,
      `Current Meter: ${selectedMeter.shortLabel}`,
      `Current Meter Max BTU: ${selectedMeter.maxBTU}`,
      `Total Connected Load: ${result.totalLoad}`,
      `Meter Result: ${result.overloadedMeter ? 'Upgrade Required' : 'Meter Appears Adequate'}`,
      `Recommended Meter: ${result.nextRecommendedMeter ? `${meterClass} ${result.nextRecommendedMeter.shortLabel}` : 'Above available meter sizes'}`,
      `Pipe Check: ${selectedPipeLabel || 'Not used'}`,
      `Pipe Result: ${typeof pipeMaxBTU === 'number' ? (result.overloadedPipe ? 'Pipe/reg may be undersized' : 'Pipe/reg appears adequate') : 'Not checked'}`,
      '',
      'Load Breakdown:',
      ...result.lineItems.map((item) => `${item.name} x ${item.qty} = ${item.total} BTU`),
    ].join('\n')

    if (navigator.share) {
      try {
        await navigator.share({ title: 'Gas Meter Load Result', text })
        return
      } catch (error) {
        console.error('Share canceled or failed:', error)
      }
    }

    try {
      await navigator.clipboard.writeText(text)
      alert('Job result copied to clipboard.')
    } catch (error) {
      alert(text)
    }
  }

  async function installApp() {
    if (installPromptEvent) {
      installPromptEvent.prompt()
      try {
        const choice = await installPromptEvent.userChoice
        setInstallMessage(`Install choice: ${choice.outcome}`)
      } catch (error) {
        setInstallMessage('Install prompt was dismissed.')
      }
      setInstallPromptEvent(null)
      return
    }

    setInstallMessage('If no install prompt appears, open the app in Chrome or Safari and use Add to Home Screen.')
  }

  return (
    <div style={styles.page}>
      <div style={styles.shell}>
        <section
          style={{
            ...styles.card,
            background: salesMode ? '#fff' : '#0f172a',
            color: salesMode ? '#0f172a' : '#fff',
          }}
        >
          <div style={{ fontSize: 12, fontWeight: 800, letterSpacing: '0.18em', textTransform: 'uppercase', opacity: 0.8 }}>
            {salesMode ? 'Homeowner View' : 'Field Tool'}
          </div>
          <h1 style={{ margin: '10px 0 0', fontSize: 28, lineHeight: 1.15 }}>Gas Meter Load Calculator</h1>
          <p style={{ margin: '10px 0 0', fontSize: 14, lineHeight: 1.5, opacity: 0.85 }}>
            {salesMode
              ? 'Simple homeowner-facing summary of the gas load versus meter capacity.'
              : 'Select meter type, add gas appliances, and get a quick meter recommendation.'}
          </p>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 16 }}>
            <button
              type="button"
              onClick={() => setSalesMode((prev) => !prev)}
              style={{
                ...styles.button,
                background: salesMode ? '#0f172a' : '#fff',
                color: salesMode ? '#fff' : '#0f172a',
                borderColor: salesMode ? '#0f172a' : '#fff',
              }}
            >
              {salesMode ? 'Exit Sales Mode' : 'Sales Mode'}
            </button>
            <button
              type="button"
              onClick={installApp}
              style={{ ...styles.button, background: '#10b981', color: '#fff', borderColor: '#10b981' }}
            >
              Install App
            </button>
          </div>

          {installMessage ? <div style={{ marginTop: 12, fontSize: 12, opacity: 0.85 }}>{installMessage}</div> : null}
        </section>

        {!salesMode ? (
          <>
            <section style={styles.card}>
              <label style={{ display: 'block', marginBottom: 8, fontSize: 14, fontWeight: 600 }}>Customer Name</label>
              <input style={styles.input} value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Customer name" />
              <label style={{ display: 'block', margin: '14px 0 8px', fontSize: 14, fontWeight: 600 }}>Job Address</label>
              <input style={styles.input} value={jobAddress} onChange={(e) => setJobAddress(e.target.value)} placeholder="Job address" />
            </section>

            <section style={styles.card}>
              <div style={{ marginBottom: 8, fontSize: 14, fontWeight: 600 }}>Meter Sizing Type</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                {['AC', 'LC'].map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => handleMeterClassChange(type)}
                    style={{
                      ...styles.button,
                      ...(meterClass === type ? styles.activeButton : {}),
                    }}
                  >
                    {type}
                  </button>
                ))}
              </div>

              <div style={{ margin: '16px 0 8px', fontSize: 14, fontWeight: 600 }}>Gas Meter Size</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
                {activeMeterOptions.map((option) => (
                  <button
                    key={`${meterClass}-${option.id}`}
                    type="button"
                    onClick={() => setSelectedMeterId(option.id)}
                    style={{
                      ...styles.button,
                      ...(selectedMeterId === option.id ? styles.activeButton : {}),
                    }}
                  >
                    {option.shortLabel}
                  </button>
                ))}
              </div>

              <div style={{ margin: '16px 0 8px', fontSize: 14, fontWeight: 600 }}>Gas Pipe / Reg Check</div>
              <div style={{ display: 'grid', gap: 10 }}>
                {pipeOptions.map((option) => (
                  <button
                    key={option.id}
                    type="button"
                    onClick={() => setSelectedPipe(option.id)}
                    style={{
                      ...styles.button,
                      textAlign: 'left',
                      ...(selectedPipe === option.id ? styles.activeButton : {}),
                    }}
                  >
                    {option.label}
                  </button>
                ))}
              </div>

              <div style={{ marginTop: 12, fontSize: 12, color: '#64748b' }}>
                {meterClass} sizing selected. Current max meter load: {formatNumber(selectedMeter.maxBTU)} BTU.
              </div>
            </section>

            <section style={styles.card}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, marginBottom: 12 }}>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700 }}>Appliance Counts</div>
                  <div style={{ fontSize: 12, color: '#64748b' }}>Tap plus or minus for fast field entry.</div>
                </div>
                <button type="button" onClick={resetAll} style={styles.button}>
                  Reset
                </button>
              </div>

              <div style={{ display: 'grid', gap: 12 }}>
                {applianceCatalog.map((item) => (
                  <div key={item.key} style={{ border: '1px solid #e2e8f0', borderRadius: 20, padding: 12 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}>
                      <div>
                        <div style={{ fontSize: 14, fontWeight: 700 }}>{item.name}</div>
                        <div style={{ fontSize: 12, color: '#64748b' }}>{formatNumber(item.btu)} BTU each</div>
                      </div>
                      <div style={{ textAlign: 'right' }}>
                        <div style={{ fontSize: 12, color: '#64748b' }}>Qty</div>
                        <div style={{ fontSize: 22, fontWeight: 800 }}>{counts[item.key]}</div>
                      </div>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '56px 1fr 56px', gap: 12, marginTop: 12 }}>
                      <button
                        type="button"
                        onClick={() => setQty(item.key, Math.max(0, Number(counts[item.key] || 0) - 1))}
                        style={{ ...styles.button, fontSize: 24 }}
                      >
                        −
                      </button>
                      <input
                        type="number"
                        min="0"
                        step="1"
                        value={counts[item.key]}
                        onChange={(e) => setQty(item.key, e.target.value)}
                        style={{ ...styles.input, textAlign: 'center', fontWeight: 700 }}
                      />
                      <button
                        type="button"
                        onClick={() => setQty(item.key, Number(counts[item.key] || 0) + 1)}
                        style={{ ...styles.button, fontSize: 24 }}
                      >
                        +
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </>
        ) : null}

        <section
          style={{
            ...styles.card,
            background: result.overloadedMeter ? '#dc2626' : '#059669',
            color: '#fff',
          }}
        >
          <div style={{ fontSize: 12, fontWeight: 800, letterSpacing: '0.18em', textTransform: 'uppercase', opacity: 0.85 }}>
            Upgrade Badge
          </div>
          <div style={{ marginTop: 10, fontSize: 34, fontWeight: 900 }}>{result.overloadedMeter ? 'Upgrade Required' : 'Meter OK'}</div>
          <div style={{ marginTop: 10, fontSize: 17, fontWeight: 700 }}>Current Meter Max: {formatNumber(selectedMeter.maxBTU)} BTU</div>
          <div style={{ marginTop: 6, fontSize: 17, fontWeight: 700 }}>Total Connected Load: {formatNumber(result.totalLoad)} BTU</div>
          <div style={{ marginTop: 10, fontSize: 14, opacity: 0.92 }}>
            {result.overloadedMeter
              ? `Over by ${formatNumber(Math.abs(result.remainingMeter))} BTU`
              : `Remaining capacity: ${formatNumber(result.remainingMeter)} BTU`}
          </div>
          <div style={{ marginTop: 6, fontSize: 14, opacity: 0.92 }}>Meter utilization: {result.percentUsed.toFixed(1)}%</div>
        </section>

        <section style={{ ...styles.card, background: '#0f172a', color: '#fff' }}>
          <div style={{ fontSize: 12, fontWeight: 800, letterSpacing: '0.18em', textTransform: 'uppercase', opacity: 0.85 }}>
            Auto Recommendation
          </div>
          <div style={{ marginTop: 10, fontSize: 28, fontWeight: 900 }}>{recommendationText}</div>
          <div style={{ marginTop: 10, fontSize: 14, opacity: 0.85 }}>
            This recommends the smallest built-in meter size that covers the calculated load.
          </div>
        </section>

        <section style={styles.card}>
          <div style={{ fontSize: 14, fontWeight: 700 }}>Gas Pipe Check</div>
          {typeof pipeMaxBTU !== 'number' ? (
            <div style={{ marginTop: 10, fontSize: 14, color: '#64748b' }}>No pipe/reg check selected.</div>
          ) : (
            <div style={{ display: 'grid', gap: 10, marginTop: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', background: '#f8fafc', padding: '10px 12px', borderRadius: 16 }}>
                <span>Selected Pipe / Reg</span>
                <strong>{selectedPipeLabel}</strong>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', background: '#f8fafc', padding: '10px 12px', borderRadius: 16 }}>
                <span>Pipe / Reg Max BTU</span>
                <strong>{formatNumber(pipeMaxBTU)} BTU</strong>
              </div>
              <div
                style={{
                  padding: '12px 14px',
                  borderRadius: 16,
                  fontWeight: 700,
                  background: result.overloadedPipe ? '#fef2f2' : '#ecfdf5',
                  color: result.overloadedPipe ? '#b91c1c' : '#047857',
                }}
              >
                {result.overloadedPipe
                  ? `Pipe/reg may be undersized by ${formatNumber(Math.abs(result.remainingPipe || 0))} BTU.`
                  : `Pipe/reg appears adequate. Remaining pipe capacity: ${formatNumber(result.remainingPipe || 0)} BTU.`}
              </div>
            </div>
          )}
        </section>

        {!salesMode ? (
          <>
            <section style={styles.card}>
              <div style={{ fontSize: 14, fontWeight: 700 }}>Selected Load Breakdown</div>
              {result.lineItems.length === 0 ? (
                <div style={{ marginTop: 10, fontSize: 14, color: '#64748b' }}>No appliances added yet.</div>
              ) : (
                <div style={{ display: 'grid', gap: 10, marginTop: 12 }}>
                  {result.lineItems.map((item) => (
                    <div
                      key={item.key}
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        gap: 12,
                        padding: '10px 12px',
                        borderRadius: 16,
                        background: '#f8fafc',
                      }}
                    >
                      <span>{item.name} × {item.qty}</span>
                      <strong>{formatNumber(item.total)} BTU</strong>
                    </div>
                  ))}
                </div>
              )}
            </section>

            <section style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <button type="button" onClick={saveJob} style={{ ...styles.button, background: '#0f172a', color: '#fff', borderColor: '#0f172a' }}>
                Save Job
              </button>
              <button type="button" onClick={exportJob} style={{ ...styles.button, background: '#10b981', color: '#fff', borderColor: '#10b981' }}>
                Export Result
              </button>
            </section>

            <section style={styles.card}>
              <div style={{ fontSize: 14, fontWeight: 700 }}>Recent Saved Jobs</div>
              {savedJobs.length === 0 ? (
                <div style={{ marginTop: 10, fontSize: 14, color: '#64748b' }}>No jobs saved yet.</div>
              ) : (
                <div style={{ display: 'grid', gap: 10, marginTop: 12 }}>
                  {savedJobs.map((job) => (
                    <div key={job.id} style={{ background: '#f8fafc', borderRadius: 18, padding: 12 }}>
                      <div style={{ fontSize: 14, fontWeight: 700 }}>{job.customerName}</div>
                      <div style={{ marginTop: 4, fontSize: 12, color: '#64748b' }}>{job.jobAddress || 'No address entered'}</div>
                      <div style={{ marginTop: 8, fontSize: 12, color: '#64748b' }}>{job.timestamp}</div>
                      <div style={{ marginTop: 8, fontSize: 14 }}>Load: {formatNumber(job.totalLoad)} BTU</div>
                      <div style={{ marginTop: 4, fontSize: 14 }}>Recommendation: {job.recommendation}</div>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </>
        ) : null}

        <section style={{ ...styles.card, background: '#fffbeb', borderColor: '#fde68a', color: '#92400e' }}>
          This PWA stores job history on the device, works offline after first load, and is ready for deployment to Vercel or Netlify.
        </section>
      </div>
    </div>
  )
}
