# Gas Meter Load Calculator PWA

## Run locally

1. Install Node.js 18+
2. Open a terminal in this folder
3. Run:

```bash
npm install
npm run dev
```

## Build for production

```bash
npm install
npm run build
```

The production files will be in `dist/`.

## Deploy on Vercel

1. Create a new Vercel project
2. Upload this folder or connect it to GitHub
3. Framework preset: **Vite**
4. Build command: `npm run build`
5. Output directory: `dist`

## Install on phone

After deployment:

- iPhone Safari: Share -> Add to Home Screen
- Android Chrome: Open app -> Install App or Add to Home Screen

## Notes

- Works offline after the first successful load
- Saves recent jobs in local storage on the device
- Uses the meter and appliance values supplied in your worksheet
